<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once(dirname(__FILE__) . '/classes/FaktoriaHelper.php');
require_once dirname(__FILE__).'/models/FaktoriaPayments.php';

class Faktoria extends PaymentModule
{
    private $_html = '';
    private $_availableCurrency = 'PLN';

    private $minAmount = 500;
    private $maxAmount = 30000;

    private $_faktoriaApiLink = 'https://api.faktoria.pl/fpay/';
    private $_faktoriaSandboxApiLink = 'https://api.faktoria.pl/fpay-sandbox/';

    const INITIAL_STATE     = 'FAKTORIA_ORDER_INITIAL_STATE';
    const NEW_STATE         = 'FAKTORIA_ORDER_NEW_STATE';
    const ACCEPTED_STATE    = 'FAKTORIA_ORDER_ACCEPTED_STATE';
    const REJECTED_STATE    = 'FAKTORIA_ORDER_REJECTED_STATE';
    const ERROR_STATE       = 'FAKTORIA_ORDER_ERROR_STATE';
    const GIVEUP_STATE      = 'FAKTORIA_ORDER_GIVEUP_STATE';

  private $_stateMapper = [
      200 => self::ACCEPTED_STATE,
      400 => self::ERROR_STATE,
      401 => self::REJECTED_STATE,
      501 => self::GIVEUP_STATE,
      502 => self::ERROR_STATE
    ];


    private $tabOrderState = [
        self::INITIAL_STATE => [
            'pl' => '[Spingo] Oczekuje na złożenie wniosku',
            'en' => '[Spingo] Awaiting submission of the application',
            'color' => '#51a4ff',
            'template' => ''
        ],
        self::NEW_STATE => [
            'pl' => '[Spingo] Wniosek przyjęty przez Spingo',
            'en' => '[Spingo] Application sent to Spingo',
            'color' => '#01B887',
            'template' => ''
        ],
        self::ACCEPTED_STATE => [
            'pl' => '[Spingo] Wniosek zaakceptowany przez Spingo',
            'en' => '[Spingo] Application accepted by Spingo',
            'color' => '#39c400',
            'template' => 'faktoria_accept'
        ],
        self::REJECTED_STATE => [
            'pl' => '[Spingo] Wniosek odrzucony przez Spingo',
            'en' => '[Spingo] Application rejected by Spingo',
            'color' => '#e74c3c',
            'template' => ''
        ],
        self::ERROR_STATE => [
            'pl' => '[Spingo] Błąd podczas przesyłania wniosku do Spingo',
            'en' => '[Spingo] ERROR while send Application to Spingo',
            'color' => '#3f1007',
            'template' => ''
        ],
        self::GIVEUP_STATE => [
            'pl' => '[Spingo] Klient zrezygnował z wniosku w Spingo',
            'en' => '[Spingo] The client declined the application in Spingo',
            'color' => '#f75474',
            'template' => ''
        ],
    ];



    public function __construct()
    {
        $this->name = 'faktoria';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.5';
        $this->ps_versions_compliancy = ['min' => '1.6.0', 'max' => _PS_VERSION_];
        $this->author = 'Spingo';
        $this->is_eu_compatible = 1;
        $this->controllers = ['payment', 'return'];
        $this->bootstrap = true;

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        parent::__construct();

        $this->displayName = $this->l('Spingo payment');
        $this->description = $this->l('Accepts payments by Spingo');
        $this->confirm_uninstall = $this->l('Are you sure you want to uninstall? You will lose all your settings!');
        $this->callToActionText = $this->l('SPINGO - deferred payments to the company');
    }

    public function install()
    {
        if (!parent::install() ||
            !$this->createDbTables() ||
            !$this->createModuleSettings() ||
            !$this->registerHooks()
        ) {
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        if (!$this->unregisterHooks() ||
            !$this->deleteModuleSettings() ||
            !$this->deleteDbTables() ||
            !parent::uninstall()) {
            return false;
        }
        return true;
    }

    private function createDbTables()
    {
        return Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'faktoria_payments` (
            `id_faktoria_payment` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY ,
            `id_order` INT(10) UNSIGNED NOT NULL,
            `id_faktoria` varchar(255)  NOT NULL,
            `faktoria_key` varchar(255)  NOT NULL,
            `status` INT(10) NOT NULL,
            `date_add` datetime,
            `date_upd` datetime,
            UNIQUE (`id_order`)
        )');
    }

    private function deleteDbTables(){
        return Db::getInstance()->Execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'faktoria_payments`');
    }

    private function registerHooks()
    {
        $registerStatus = $this->registerHook('actionFrontControllerSetMedia') &&
            $this->registerHook('displayOrderDetail') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('actionOrderHistoryAddAfter') &&
            $this->registerHook('displayFooter')
        ;

        if (version_compare(_PS_VERSION_, '1.7', 'lt')) {
            $registerStatus &= $this->registerHook('payment') &&
                $this->registerHook('displayPaymentEU') &&
                $this->registerHook('displayProductButtons')
            ;
            $this->updatePosition(Hook::getIdByName('displayPayment'), false, 1);
            $this->updatePosition(Hook::getIdByName('displayPaymentEU'), false, 1);
        } else {
            $registerStatus &= $this->registerHook('paymentOptions');
            $this->updatePosition(Hook::getIdByName('paymentOptions'), false, 1);

            $registerStatus &= $this->registerHook('displayHeaderCategory') &&
                $this->registerHook('displayFooterCategory') &&
                $this->registerHook('displayProductAdditionalInfo') &&
                $this->registerHook('displayReassurance');
        }

        return $registerStatus;
    }

    private function unregisterHooks()
    {
        $registerStatus = $this->unregisterHook('actionFrontControllerSetMedia') &&
            $this->unregisterHook('displayOrderDetail') && $this->unregisterHook('paymentReturn');

        if (version_compare(_PS_VERSION_, '1.7', 'lt')) {
            $registerStatus &= $this->unregisterHook('displayPaymentEU') &&
                $this->unregisterHook('payment');
        } else {
            $registerStatus &= $this->unregisterHook('paymentOptions');
        }

        return $registerStatus;
    }


    private function createModuleSettings()
    {
        $ret =  Configuration::updateValue('FAKTORIA_API_KEY', '') &&
            Configuration::updateValue('FAKTORIA_CONTRACT_ID', '') &&
            Configuration::updateValue('FAKTORIA_MERCHANT_ID', '') &&
            Configuration::updateValue('FAKTORIA_SANDBOX_API_KEY', '') &&
            Configuration::updateValue('FAKTORIA_SANDBOX_MODE', 0);

        foreach($this->tabOrderState as $state => $params){
            $ret &= Configuration::updateValue(
                $state,
                $this->createState($state, $params)
            );

        }

        return $ret;
    }

    private function deleteModuleSettings()
    {
        $ret = Configuration::deleteByName('FAKTORIA_API_KEY') &&
            Configuration::deleteByName('FAKTORIA_SANDBOX_API_KEY') &&
            Configuration::deleteByName('FAKTORIA_SANDBOX_MODE') &&
            Configuration::deleteByName('FAKTORIA_BANER_LINK') &&
            Configuration::deleteByName('FAKTORIA_BANER_THEME') &&
            Configuration::deleteByName('FAKTORIA_BANER_ON_PRODUCT_PAGE') &&
            Configuration::deleteByName('FAKTORIA_BANER_ON_LIST_TOP') &&
            Configuration::deleteByName('FAKTORIA_BANER_ON_LIST_BOTTOM') &&
            Configuration::deleteByName('FAKTORIA_POPUP_ON') &&
            Configuration::deleteByName('FAKTORIA_POPUP_SECONDS') &&
            Configuration::deleteByName('FAKTORIA_POPUP_SHOW_TIMES');

        return $ret;
    }

    public function createState($state, array $params)
    {
        if (Configuration::get($state) ||
            Validate::isLoadedObject(new OrderState(Configuration::get($state)))) {
            return Configuration::get($state);
        }

        $order_state = new OrderState();
        $languages = Language::getLanguages(false);
        foreach ($languages as $language) {
            if (Tools::strtolower($language['iso_code']) == 'pl') {
                $order_state->name[$language['id_lang']] = $params['pl'];
            } else {
                $order_state->name[$language['id_lang']] = $params['en'];
            }
        }

        $order_state->send_email = false;
        $order_state->invoice = false;
        $order_state->unremovable = true;
        $order_state->hidden = false;
        $order_state->delivery = false;
        $order_state->logable = false;
        $order_state->color = $params['color'];
        $order_state->module_name = $this->name;

        if ($order_state->add()) {
            $source = _PS_MODULE_DIR_ . $this->name . '/views/img/spingo.gif';
            $destination = _PS_ROOT_DIR_ . '/img/os/' . $order_state->id . '.gif';
            copy($source, $destination);
        }

        return $order_state->id;
    }


    public function hookActionFrontControllerSetMedia()
    {
        $this->context->controller->addCSS(($this->_path) . 'views/css/front.css', 'all');

        if($this->blockPopup()){
            return true;
        }

        if (version_compare(_PS_VERSION_, '1.7', 'lt')) {
            $this->context->controller->addJquery();
            $this->context->controller->addCSS(($this->_path) . 'views/css/front16.css', 'all');
        }
        $this->context->controller->addJqueryPlugin('cooki-plugin');

        $this->context->controller->addJS(($this->_path) . 'views/js/front.js');
    }

    private function blockPopup(){
        if(
            isset($this->context->controller) &&
            (
                (
                    $this->context->controller instanceof CMSController &&
                    isset($this->context->controller->cms) &&
                    $this->context->controller->cms->id == (int)Configuration::get('FAKTORIA_BANER_LINK')
                )
                ||
                $this->context->controller instanceof CartController ||
                $this->context->controller instanceof OrderController ||
                $this->context->controller instanceof OrderOpcController
            )
        ){
            return true;
        }

        return false;
    }

    private function isActive($params)
    {
        $helper = new FaktoriaHelper;
        $idCart = $params['cart']->id;
        $idDeliveryAddress = $params['cart']->id_address_delivery;
        $idInvoiceAddress = $params['cart']->id_address_invoice;
        if(isset($params['order']) && $params['order'] instanceof Order){
            $idCart = $params['order']->id_cart;
            $idDeliveryAddress = $params['order']->id_address_delivery;
            $idInvoiceAddress = $params['order']->id_address_invoice;
        }

        $cart = new Cart($idCart);

        if(!($cart instanceof Cart)){
            return false;
        }

        $cartValue = $cart->getOrderTotal(true);

        if (
            !$this->active ||
            !$this->checkCurrency($cart) ||
            !$this->isConfigured() ||
            $cartValue < $this->minAmount ||
            $cartValue > $this->maxAmount ||
            !$helper->getAddressNIP($idInvoiceAddress, $idDeliveryAddress)
        ) {
            return false;
        }

        return true;
    }

    private function isConfigured()
    {
        if(!Configuration::get('FAKTORIA_SANDBOX_MODE') && Configuration::get('FAKTORIA_API_KEY') && Configuration::get('FAKTORIA_CONTRACT_ID') && Configuration::get('FAKTORIA_MERCHANT_ID')){
            return true;
        }

        if(Configuration::get('FAKTORIA_SANDBOX_MODE') && Configuration::get('FAKTORIA_SANDBOX_API_KEY') && Configuration::get('FAKTORIA_SANDBOX_CONTRACT_ID') && Configuration::get('FAKTORIA_SANDBOX_MERCHANT_ID')){
            return true;
        }

        return false;
    }


    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if ($currency_order->iso_code === $this->_availableCurrency && is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }

        return false;
    }

    public function hookActionOrderHistoryAddAfter($params){

        if(!isset($params['order_history']) || !($params['order_history'] instanceof OrderHistory)){
            return;
        }

        switch($params['order_history']->id_order_state){
            case Configuration::get('FAKTORIA_ORDER_INITIAL_STATE'):
                $template = $this->tabOrderState[self::INITIAL_STATE]['template'];
                break;
            case Configuration::get('FAKTORIA_ORDER_NEW_STATE'):
                $template = $this->tabOrderState[self::NEW_STATE]['template'];
                break;
            case Configuration::get('FAKTORIA_ORDER_ACCEPTED_STATE'):
                $template = $this->tabOrderState[self::ACCEPTED_STATE]['template'];
                break;
            case Configuration::get('FAKTORIA_ORDER_REJECTED_STATE'):
                $template = $this->tabOrderState[self::REJECTED_STATE]['template'];
                break;
            case Configuration::get('FAKTORIA_ORDER_ERROR_STATE'):
                $template = $this->tabOrderState[self::ERROR_STATE]['template'];
                break;
            case Configuration::get('FAKTORIA_ORDER_GIVEUP_STATE'):
                $template = $this->tabOrderState[self::GIVEUP_STATE]['template'];
                break;
            default:
                $template = "";
                break;
        }

        if($template){
            $order = new Order($params['order_history']->id_order);
            $customer = $order->getCustomer();

            $templateVars = [
                '{shop_url}' => $this->context->link->getPageLink('index', true),
                '{shop_name}' => $this->context->shop->name,
                '{firstname}' => $customer->firstname,
                '{lastname}' => $customer->lastname,
                '{order_name}' => $order->reference,
                '{guest_tracking_url}' => $this->context->link->getPageLink('guest-tracking', true),
            ];


            $imageDir = Configuration::get('_PS_IMG_DIR_');
            $baseUrl = $this->context->link->getBaseLink();

            //Logo url
            $logoMail = Configuration::get('PS_LOGO_MAIL');
            $logo = Configuration::get('PS_LOGO');
            if (!empty($logoMail) && file_exists($imageDir . $logoMail)) {
                $templateVars['{shop_logo}'] = $baseUrl . 'img/' . $logoMail;
            } else {
                if (!empty($logo) && file_exists($imageDir . $logo)) {
                    $templateVars['{shop_logo}'] = $baseUrl . 'img/' . $logo;
                } else {
                    $templateVars['{shop_logo}'] = '';
                }
            }


            Mail::send(
                $this->context->language->id,
                $template,
                $this->l('Spingo request state has changed.'),
                $templateVars,
                $customer->email,
                null,
                null,
                null,
                null,
                null,
                dirname(__FILE__) . '/mails/',
                false,
                $this->context->shop->id
            );
        }

    }


    public function hookPaymentOptions($params)
    {

        if (!$this->isActive($params)) {
            return;
        }
        $currency = new Currency($params['cart']->id_currency);

        $html = $this->fetch('module:faktoria/views/templates/hook/payment_option.tpl', null);

        $payment_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $payment_option->setModuleName($this->name)
            ->setCallToActionText($this->callToActionText)
            ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/spingo_payment_option.png'))
            ->setAdditionalInformation($html)
            ->setModuleName($this->name)
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', [], true));

        return [$payment_option];
    }

    public function getApiLink(){
        return (Configuration::get('FAKTORIA_SANDBOX_MODE'))?$this->_faktoriaSandboxApiLink:$this->_faktoriaApiLink;
    }

    public function getApiKey(){
        return (Configuration::get('FAKTORIA_SANDBOX_MODE'))?Configuration::get('FAKTORIA_SANDBOX_API_KEY'):Configuration::get('FAKTORIA_API_KEY');
    }

    public function getApiIds($name){
        return (Configuration::get('FAKTORIA_SANDBOX_MODE'))?Configuration::get('FAKTORIA_SANDBOX_'.$name):Configuration::get('FAKTORIA_'.$name);
    }

    public function hookPaymentReturn($params)
    {
        $customer = [];

        if(version_compare(_PS_VERSION_, '1.7', 'lt')){
            $params['order'] = $params['objOrder'];
        }

        if (!$this->isActive($params) || !($params['order'] instanceof Order)) {
            return;
        }


        $customerObj = $params['order']->getCustomer();

        $customer = [
            'firstname' => $customerObj->firstname,
            'lastname' => $customerObj->lastname,
            'email' => $customerObj->email,
        ];


        if($params['order']->id_address_invoice){
            $addressObj = new Address($params['order']->id_address_invoice);
            if($addressObj instanceof Address){
                $customer['phone'] = ($addressObj->phone_mobile)?$addressObj->phone_mobile:$addressObj->phone;
            }
        }

        $currency = new Currency($params['order']->id_currency);
        $config = $this->getConfigFieldsValues();

        $state = $params['order']->getCurrentState();

        if ( $state == (int)Configuration::get(self::INITIAL_STATE) ) {

            $this->smarty->assign(array(
                'status' => 'ok'
            ));
        } else {
            $this->smarty->assign(
                array(
                    'status' => 'failed'
                )
            );
        }

        $isSend = FaktoriaPayments::checkIsSend($params['order']->id);
        if((Tools::getValue('sendToFaktoria') || $params['order']->isAssociatedAtGuest($customerObj->email)) && !$isSend){
            $helper = new FaktoriaHelper;
            $return = $helper->sendRequest($params['order']);

            if(isset($return['applicationNumber']) && $return['applicationNumber'] && isset($return['fieldInfos'])){
              $payments = FaktoriaPayments::findForOrder($params['order']->id);

              if(isset($payments['id_faktoria_payment'])){
                $faktoria = new FaktoriaPayments($payments['id_faktoria_payment']);
              }
              else{
                  $faktoria = new FaktoriaPayments();
                  $faktoria->id_order = $params['order']->id;
                  $faktoria->faktoria_key = md5(_COOKIE_KEY_ . $params['order']->id);

              }

              $faktoria->id_faktoria = $return['applicationNumber'];
              $faktoria->save();
              Tools::redirect(reset($return['fieldInfos']));
            }
            else{
              $this->smarty->assign([
                  'errorMsg' => $this->displayError($this->l('Error while processing request'))
              ]);
            }
        }

        $theme = (Configuration::get('FAKTORIA_BANER_THEME'))?Configuration::get('FAKTORIA_BANER_THEME'):'light';
        $logoImg = "spingo_payment_return_".$theme.".png";

        $this->smarty->assign($customer);
        $this->smarty->assign(
            [
                'logo' => $this->getBaner($logoImg),
                'isSend' => $isSend,
            ]
        );
        if(version_compare(_PS_VERSION_, '1.7', 'lt')){
            return $this->display(__FILE__, '/views/templates/hook/payment_return.tpl');
        }
        else{
            return $this->fetch('module:faktoria/views/templates/hook/payment_return.tpl');
        }
    }

    public function hookDisplayFooter($params = []){
        if (!(int)Configuration::get('FAKTORIA_POPUP_ON') || $this->blockPopup()) {
            return;
        }

        $popupLink = ($idCms = Configuration::get('FAKTORIA_BANER_LINK'))?$this->context->link->getCMSLink($idCms):"https://spingo.pl/";

        $this->context->smarty->assign([
            'popupLink' => $popupLink,
            'popupImg' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/spingo_popup_v2.png'),
            'secounds' => (int)Configuration::get('FAKTORIA_POPUP_SECONDS'),
            'foruser' => (int)Configuration::get('FAKTORIA_POPUP_SHOW_TIMES'),
        ]);

        return $this->display(__FILE__, '/views/templates/hook/footer.tpl');
    }

    public function hookPayment($params)
    {
        if (!$this->isActive($params)) {
            return;
        }

        $this->context->smarty->assign([
            'cta_text' => $this->callToActionText,
            'logo' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/spingo_payment_option.png'),
            'moduleUrl' => $this->context->link->getModuleLink($this->name, 'payment'),
            'opc' => ($this->context->controller instanceof OrderOpcController)?true:false,
        ]);

        return $this->display(__FILE__, '/views/templates/hook/payment.tpl');
    }

    public function hookDisplayProductButtons($params){
        return  $this->hookDisplayProductAdditionalInfo($params);
    }

    public function hookDisplayProductAdditionalInfo($params){
        return $this->listBaner('PRODUCT_PAGE');
    }


    public function hookDisplayHeaderCategory($params = []){
        return $this->listBaner('LIST_TOP');
    }

    public function hookDisplayFooterCategory($params = []){
        return $this->listBaner('LIST_BOTTOM');
    }

    public function hookDisplayReassurance($params = []){
        if(
          !($this->context->controller instanceof CartController) &&
          !($this->context->controller instanceof OrderController)
        ){
          return "";
        }

        return $this->listBaner('CART_PAGE');
    }

    public function listBaner($place){
        if(!Configuration::get('FAKTORIA_BANER_ON_'.$place)){
            return false;
        }

        $theme = (Configuration::get('FAKTORIA_BANER_THEME'))?Configuration::get('FAKTORIA_BANER_THEME'):'light';
        $baner = ($place == 'PRODUCT_PAGE' || $place == 'CART_PAGE')?"faktoria_spingo_product_detail_".$theme.".png":"faktoria_spingo_product_list_".$theme.".png";

        $link = ($idCms = Configuration::get('FAKTORIA_BANER_LINK'))?$this->context->link->getCMSLink($idCms):"https://spingo.pl/";
        $this->smarty->assign([
            'link' => $link,
            'baner' => $this->getBaner($baner)
        ]);

        return $this->display(__FILE__, '/views/templates/hook/product_baner.tpl');
    }

    public function hookDisplayPaymentEU()
    {
        return [
            'cta_text' => $this->callToActionText,
            'logo' => $this->getLogo(),
            'action' => $this->context->link->getModuleLink($this->name, 'payment')
        ];
    }

    public function getLogo()
    {
        return Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/spingo-logo.jpg');
    }

    public function getBaner($name)
    {
        return Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/'.$name);
    }

    private function postProcess()
    {
        if(!Tools::getValue('submitfaktoria')){
            return;
        }

        if(
            !Tools::getValue('FAKTORIA_API_KEY') ||
            !Tools::getValue('FAKTORIA_CONTRACT_ID') ||
            !Tools::getValue('FAKTORIA_MERCHANT_ID')
        ){
            $this->_html .= $this->displayError($this->l('Please fill all required fields'));
            return;
        }


        Configuration::updateValue(
            'FAKTORIA_API_KEY',
            Tools::getValue('FAKTORIA_API_KEY')
        );

        Configuration::updateValue(
            'FAKTORIA_CONTRACT_ID',
            Tools::getValue('FAKTORIA_CONTRACT_ID')
        );

        Configuration::updateValue(
            'FAKTORIA_MERCHANT_ID',
            Tools::getValue('FAKTORIA_MERCHANT_ID')
        );

        Configuration::updateValue(
            'FAKTORIA_BROKER_ID',
            Tools::getValue('FAKTORIA_BROKER_ID')
        );

        Configuration::updateValue(
            'FAKTORIA_SANDBOX_API_KEY',
            Tools::getValue('FAKTORIA_SANDBOX_API_KEY')
        );

        Configuration::updateValue(
            'FAKTORIA_SANDBOX_CONTRACT_ID',
            Tools::getValue('FAKTORIA_SANDBOX_CONTRACT_ID')
        );

        Configuration::updateValue(
            'FAKTORIA_SANDBOX_MERCHANT_ID',
            Tools::getValue('FAKTORIA_SANDBOX_MERCHANT_ID')
        );


        Configuration::updateValue(
            'FAKTORIA_SANDBOX_MODE',
            Tools::getValue('FAKTORIA_SANDBOX_MODE')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_LINK',
            Tools::getValue('FAKTORIA_BANER_LINK')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_THEME',
            Tools::getValue('FAKTORIA_BANER_THEME')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_ON_PRODUCT_PAGE',
            Tools::getValue('FAKTORIA_BANER_ON_PRODUCT_PAGE')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_ON_LIST_TOP',
            Tools::getValue('FAKTORIA_BANER_ON_LIST_TOP')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_ON_LIST_BOTTOM',
            Tools::getValue('FAKTORIA_BANER_ON_LIST_BOTTOM')
        );

        Configuration::updateValue(
            'FAKTORIA_BANER_ON_CART_PAGE',
            Tools::getValue('FAKTORIA_BANER_ON_CART_PAGE')
        );

        Configuration::updateValue(
            'FAKTORIA_POPUP_ON',
            Tools::getValue('FAKTORIA_POPUP_ON')
        );

        Configuration::updateValue(
            'FAKTORIA_POPUP_SECONDS',
            Tools::getValue('FAKTORIA_POPUP_SECONDS')
        );

        Configuration::updateValue(
            'FAKTORIA_POPUP_SHOW_TIMES',
            Tools::getValue('FAKTORIA_POPUP_SHOW_TIMES')
        );

        foreach(array_keys($this->tabOrderState) as $state){
            Configuration::updateValue(
                $state,
                Tools::getValue($state)
            );
        }


        $this->_html .= $this->displayConfirmation($this->l('Configuration updated'));
    }


    public function getContent()
    {
        $this->_html = $this->adminDisplayInformation($this->l('Link to payments statuses:')."<br />".$this->context->link->getModuleLink($this->getName(), 'status'));
        if (Tools::isSubmit('submit' . $this->name)) {
            $this->postProcess();
        }
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    private function renderForm()
    {
        $form = [];

        $form['payment_company_info'] = [
            'form' => [
                'legend' => [
                    'title' => $this->l('API configration'),
                    'icon' => 'icon-cog'
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('API KEY'),
                        'name' => 'FAKTORIA_API_KEY',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Contract ID'),
                        'name' => 'FAKTORIA_CONTRACT_ID',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Merchant ID'),
                        'name' => 'FAKTORIA_MERCHANT_ID',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Broker ID'),
                        'name' => 'FAKTORIA_BROKER_ID',
                        'required' => false
                    ],
                ],

                'submit' => [
                    'title' => $this->l('Save')
                ]
            ]
        ];

        $form['sandbox_mode'] = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Sandbox Mode'),
                    'icon' => 'icon-cog'
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Sandbox mode'),
                        'name' => 'FAKTORIA_SANDBOX_MODE',
                        'values' => [
                            [
                                'id' => 'FAKTORIA_SANDBOX_MODE_on',
                                'value' => 1
                            ],
                            [
                                'id' => 'FAKTORIA_SANDBOX_MODE_off',
                                'value' => 0
                            ]
                        ]
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Contract ID'),
                        'name' => 'FAKTORIA_SANDBOX_CONTRACT_ID',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Merchant ID'),
                        'name' => 'FAKTORIA_SANDBOX_MERCHANT_ID',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('SANDBOX API KEY'),
                        'name' => 'FAKTORIA_SANDBOX_API_KEY',
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save')
                ]
            ]
        ];

        $order_states = OrderState::getOrderStates(ContextCore::getContext()->language->id);
        $form['payment_statuses'] = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Payment status mapping'),
                    'icon' => 'icon-cog'
                ],
                'input' => [
                    [
                        'type' => 'select',
                        'label' => $this->l('Awaiting submission of the application'),
                        'name' => self::INITIAL_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Application sent to Spingo'),
                        'name' => self::NEW_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Application accepted by Spingo'),
                        'name' => self::ACCEPTED_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Application rejected by Spingo'),
                        'name' => self::REJECTED_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Application error in Spingo'),
                        'name' => self::ERROR_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Customer has give up for application in Spingo'),
                        'name' => self::GIVEUP_STATE,
                        'options' => [
                            'query' => $order_states,
                            'id' => 'id_order_state',
                            'name' => 'name'
                        ]
                    ]
                ],
                'submit' => [
                    'title' => $this->l('Save')
                ]
            ]
        ];

        $form['baners'] = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Display Baners'),
                    'icon' => 'icon-cog'
                ],
                'input' => [
                    [
                        'type' => 'select',
                        'label' => $this->l('Banner Link'),
                        'name' => 'FAKTORIA_BANER_LINK',
                        'options' => [
                            'query' => array_merge(["-"],CMS::getCMSPages($this->context->language->id, null, true, $this->context->shop->id)),
                            'id' => 'id_cms',
                            'name' => 'meta_title'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('Banner Theme'),
                        'name' => 'FAKTORIA_BANER_THEME',
                        'options' => [
                            'query' => [
                                [
                                    'id' => 'light',
                                    'name' => $this->l('light')
                                ],
                                [
                                    'id' => 'dark',
                                    'name' => $this->l('dark')
                                ],
                            ],
                            'id' => 'id',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('On product page'),
                        'name' => 'FAKTORIA_BANER_ON_PRODUCT_PAGE',
                        'values' => [
                            [
                                'id' => 'FAKTORIA_BANER_ON_PRODUCT_PAGE_on',
                                'value' => 1
                            ],
                            [
                                'id' => 'FAKTORIA_BANER_ON_PRODUCT_PAGE_off',
                                'value' => 0
                            ]
                        ]
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save')
                ]
            ]
        ];

        if(Hook::getIdByName('displayHeaderCategory')){
            $form['baners']['form']['input'][] = [
                'type' => 'switch',
                'label' => $this->l('On product list TOP'),
                'name' => 'FAKTORIA_BANER_ON_LIST_TOP',
                'values' => [
                    [
                        'id' => 'FAKTORIA_BANER_ON_LIST_TOP_on',
                        'value' => 1
                    ],
                    [
                        'id' => 'FAKTORIA_BANER_ON_LIST_TOP_off',
                        'value' => 0
                    ]
                ]
            ];
        }

        if(Hook::getIdByName('displayFooterCategory')){
            $form['baners']['form']['input'][] = [
                'type' => 'switch',
                'label' => $this->l('On product list BOTTOM'),
                'name' => 'FAKTORIA_BANER_ON_LIST_BOTTOM',
                'values' => [
                    [
                        'id' => 'FAKTORIA_BANER_ON_LIST_BOTTOM_on',
                        'value' => 1
                    ],
                    [
                        'id' => 'FAKTORIA_BANER_ON_LIST_BOTTOM_off',
                        'value' => 0
                    ]
                ]
            ];
        }

        if(Hook::getIdByName('displayReassurance')){
            $form['baners']['form']['input'][] = [
                'type' => 'switch',
                'label' => $this->l('On cart page'),
                'name' => 'FAKTORIA_BANER_ON_CART_PAGE',
                'values' => [
                    [
                        'id' => 'FAKTORIA_BANER_ON_CART_PAGE_on',
                        'value' => 1
                    ],
                    [
                        'id' => 'FAKTORIA_BANER_ON_CART_PAGE_off',
                        'value' => 0
                    ]
                ]
            ];
        }

        $form['popup'] = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Popup settings'),
                    'icon' => 'icon-cog'
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Display popup'),
                        'name' => 'FAKTORIA_POPUP_ON',
                        'values' => [
                            [
                                'id' => 'FAKTORIA_POPUP_ON_on',
                                'value' => 1
                            ],
                            [
                                'id' => 'FAKTORIA_POPUP_ON_off',
                                'value' => 0
                            ]
                        ]
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Show popup after'),
                        'name' => 'FAKTORIA_POPUP_SECONDS',
                        'suffix' => $this->l('sec.'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Show popup for user'),
                        'name' => 'FAKTORIA_POPUP_SHOW_TIMES',
                        'suffix' => $this->l('times'),
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save')
                ]
            ]
        ];


        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->name_controller = $this->name;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->title = $this->displayName;
        $helper->submit_action = 'submit' . $this->name;
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' .
            $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        ];

        return $helper->generateForm($form);
    }

    private function getConfigFieldsValues()
    {
        $tabParams = [
            'FAKTORIA_API_KEY' => Configuration::get('FAKTORIA_API_KEY'),
            'FAKTORIA_CONTRACT_ID' => Configuration::get('FAKTORIA_CONTRACT_ID'),
            'FAKTORIA_BROKER_ID' => Configuration::get('FAKTORIA_BROKER_ID'),
            'FAKTORIA_MERCHANT_ID' => Configuration::get('FAKTORIA_MERCHANT_ID'),
            'FAKTORIA_SANDBOX_API_KEY' => Configuration::get('FAKTORIA_SANDBOX_API_KEY'),
            'FAKTORIA_SANDBOX_MODE' => Configuration::get('FAKTORIA_SANDBOX_MODE'),
            'FAKTORIA_SANDBOX_CONTRACT_ID' => Configuration::get('FAKTORIA_SANDBOX_CONTRACT_ID'),
            'FAKTORIA_SANDBOX_MERCHANT_ID' => Configuration::get('FAKTORIA_SANDBOX_MERCHANT_ID'),
            'FAKTORIA_BANER_LINK' => Configuration::get('FAKTORIA_BANER_LINK'),
            'FAKTORIA_BANER_THEME' => Configuration::get('FAKTORIA_BANER_THEME'),
            'FAKTORIA_BANER_ON_PRODUCT_PAGE' => Configuration::get('FAKTORIA_BANER_ON_PRODUCT_PAGE'),
            'FAKTORIA_BANER_ON_LIST_TOP' => Configuration::get('FAKTORIA_BANER_ON_LIST_TOP'),
            'FAKTORIA_BANER_ON_LIST_BOTTOM' => Configuration::get('FAKTORIA_BANER_ON_LIST_BOTTOM'),
            'FAKTORIA_BANER_ON_CART_PAGE' => Configuration::get('FAKTORIA_BANER_ON_CART_PAGE'),
            'FAKTORIA_POPUP_ON' => Configuration::get('FAKTORIA_POPUP_ON'),
            'FAKTORIA_POPUP_SECONDS' => Configuration::get('FAKTORIA_POPUP_SECONDS'),
            'FAKTORIA_POPUP_SHOW_TIMES' => Configuration::get('FAKTORIA_POPUP_SHOW_TIMES'),
        ];


        foreach(array_keys($this->tabOrderState) as $state){
            $tabParams[$state] = Configuration::get($state);
        }

        return $tabParams;
    }

    public function getName(){
        return $this->name;
    }

    public function getStateTabMapper($state){
      return (isset($this->_stateMapper[(int)$state]))?Configuration::get($this->_stateMapper[(int)$state]):0;
    }

    public function getTabOrderState(){
        return $this->tabOrderState;
    }
}
