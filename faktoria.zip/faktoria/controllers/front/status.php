<?php

class FaktoriaStatusModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
      $code = 0;
      $desc = 'NOK';

      if(Tools::getValue('key') && Tools::getValue('state')){
        $res = FaktoriaPayments::checkByKey(Tools::getValue('key'));
        if(isset($res['id_faktoria_payment']) && $res['id_faktoria_payment']){
          $payment = new FaktoriaPayments($res['id_faktoria_payment']);
          if($payment->id_order){
            $orderState = $this->findOrderState(Tools::getValue('state'));
            if($orderState > 0){
              $this->saveOrderState($orderState, $payment->id_order);
            }
          }
        }

        Tools::redirect($this->context->link->getPageLink('index'));
      }
      else{
        $content = Tools::file_get_contents('php://input');

        if($content){
          $tabContent = json_decode($content, true);
          if(
            isset($tabContent['IdNotify']) && $tabContent['IdNotify'] &&
            isset($tabContent['Items']) && count($tabContent['Items']) &&
            ($idFaktoriaPayment = FaktoriaPayments::checkByFaktoriaId($tabContent['IdNotify']))
          )
          {
              foreach($tabContent['Items'] as $item){
                  if(
                    isset($item['Symbol']) &&
                    strtolower($item['Symbol']) == 'status' &&
                    isset($item['Value']) && $item['Value']
                  )
                  {
                    $payment = new FaktoriaPayments($idFaktoriaPayment);
                    $payment->status = $item['Value'];
                    $payment->save();

                    $orderState = $this->module->getStateTabMapper($item['Value']);
                    if($orderState){
                      $this->saveOrderState($orderState, $payment->id_order);
                    }

                    $code = 1;
                    $desc = 'OK';
                    break;
                  }
              }
          }
        }
      }
      header('Content-Type: application/json');
      die(json_encode(['code' => $code, 'description' => $desc]));
    }

    public function findOrderState($state){
      if($state == 'cancel'){
        return Configuration::get(Faktoria::REJECTED_STATE);
      }
      return 0;
    }

    private function saveOrderState($orderState, $orderId){
      $order = new Order($orderId);

      if($orderState != $order->current_state){
        $oh = new OrderHistory();
        $oh->id_employee = 0;
        $oh->id_order = $order->id;
        $oh->changeIdOrderState($orderState, $order->id);
        $oh->add();
      }
    }
}
