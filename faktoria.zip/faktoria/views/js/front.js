$( document ).ready(function() {
   faktoriaShowPopup();
});

function faktoriaShowPopup(){
   if($.cookie('faktoria_disable_popup')){
      return true;
   }

   var secounds = parseInt($('#spingo_popup').data('secounds'));
   var forUser = parseInt($('#spingo_popup').data('user'));
   var alreadyShow = ($.cookie('faktoria_popup_shown'))?parseInt($.cookie('faktoria_popup_shown')):0;

   if(
       forUser > 0 &&
       alreadyShow >= forUser
   ){
      return true;
   }

   setTimeout(function(){
      $('#spingo_popup').modal('show');
      alreadyShow ++;
      $.cookie('faktoria_popup_shown', alreadyShow);
   },(secounds * 1000) );
}

function faktoriaClosePopup(){
   $('#spingo_popup').modal('hide');
   $.cookie('faktoria_disable_popup', 1, {expires: 365});
}
