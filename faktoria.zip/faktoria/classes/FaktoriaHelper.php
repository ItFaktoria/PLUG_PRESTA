<?php


class FaktoriaHelper
{
    public $module;
    public $db;
    public $context;

    public function __construct(){
        $this->module = new Faktoria();
        $this->db = Db::getInstance();
        $this->context = Context::getContext();
    }

    public function sendRequest($order){
        $request = $this->createRequest($order);

        return $this->connect($request, $this->module->getApiLink().'Submit');
    }

    private function connect($request, $link){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $link,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($request),
            CURLOPT_HTTPHEADER => array(
                'Ocp-Apim-Subscription-Key: '.$this->module->getApiKey(),
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        return ($code == 200)?json_decode($response, true):[];
    }

    public function getAddressNIP($idInvoiceAddress, $idDeliveryAddress){
        $invoiceAddress = new Address($idInvoiceAddress);
        if($invoiceAddress instanceof Address && preg_replace('/\D/', '', $invoiceAddress->vat_number)){
            return preg_replace('/\D/', '', $invoiceAddress->vat_number);
        }

        if($invoiceAddress instanceof Address && preg_replace('/\D/', '', $invoiceAddress->dni)){
            return preg_replace('/\D/', '', $invoiceAddress->dni);
        }

        if($idInvoiceAddress == $idDeliveryAddress){
            return "";
        }

        $deliveryAddress = new Address($idDeliveryAddress);
        if($deliveryAddress instanceof Address && preg_replace('/\D/', '', $deliveryAddress->vat_number)){
            return preg_replace('/\D/', '', $deliveryAddress->vat_number);
        }

        if($deliveryAddress instanceof Address && preg_replace('/\D/', '', $deliveryAddress->dni)){
            return preg_replace('/\D/', '', $deliveryAddress->dni);
        }

        return "";
    }

    public function createRequest($order){
        $payments = FaktoriaPayments::findForOrder($order->id);

        if(isset($payments['id_faktoria_payment'])){
          $faktoria = new FaktoriaPayments($payments['id_faktoria_payment']);
        }
        else{
          $faktoria = new FaktoriaPayments();
          $faktoria->id_order = $order->id;
          $faktoria->faktoria_key = md5(_COOKIE_KEY_ . $order->id);
          $faktoria->id_faktoria = '';
          $faktoria->date_add = date('Y-m-d H:i:s');
          $faktoria->date_upd = date('Y-m-d H:i:s');
          $faktoria->save();
        }


        $request = [
            'toSet' => [
                [
                    "name" => "FKT_FPAY_IN_TRANSACTION.ID",
                    "value" => $order->reference
                ],
                [
                    "name" => "FKT_FPAY_IN_TRANSACTION.AMMOUNT",
                    "value" => number_format($order->total_paid_tax_incl, 2, ",", "")
                ],
                [
                    "name" => "FKT_FPAY_IN_TRANSACTION.CURRENCY",
                    "value" => "PLN"
                ],
                [
                    "name" => "FKT_FPAY_IN_TRANSACTION.BUYER_ID",
                    "value" => $this->getAddressNIP($order->id_address_invoice, $order->id_address_delivery)
                ],
                [
                    "name" => "FKT_FPAY_IN_LOG.CONTRACT_ID",
                    "value" => $this->module->getApiIds('CONTRACT_ID')
                ],
                [
                    "name" => "FKT_FPAY_IN_LOG.MERCHANT_ID",
                    "value" => $this->module->getApiIds('MERCHANT_ID')
                ],
                [
                    "name" => "FKT_FPAY_IN_URL.URL_RETURN",
                    "value" => $this->context->link->getModuleLink($this->module->getName(), 'status', ['key' => $faktoria->faktoria_key, 'state' => 'success'])
                ],
                [
                    "name" => "FKT_FPAY_IN_URL.URL_CANCEL",
                    "value" => $this->context->link->getModuleLink($this->module->getName(), 'status', ['key' => $faktoria->faktoria_key, 'state' => 'cancel'])
                ],
                [
                    "name" => "FKT_FPAY_IN_URL.SEND_NOTIFY",
                    "value" => "1"
                ],
                [
                    "name" => "FKT_FPAY_IN_URL.URL_NOTIFY",
                    "value" => $this->context->link->getModuleLink($this->module->getName(), 'status'),
                ],
                [
                    "name" => "FKT_FPAY_IN_TRANSACTION.IP",
                    "value" => Tools::getRemoteAddr()
                ]
            ],
            'toGet' => [
                "FKT_FPAY_IN_URL.URL_APPLICATION",
                "TRANSACTION_STATUS.STATUS",
                "TRANSACTION_STATUS.DESCRIPTION"
            ]
        ];

        if(Configuration::get('FAKTORIA_BROKER_ID')){
            $request['toSet'][] = [
                "name" => "FKT_FPAY_IN_LOG.BROKER_ID",
                "value" => Configuration::get('FAKTORIA_BROKER_ID'),
            ];
        }

        return $request;
    }
}
