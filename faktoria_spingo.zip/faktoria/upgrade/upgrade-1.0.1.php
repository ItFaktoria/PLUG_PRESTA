<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1($object)
{
    if (version_compare(_PS_VERSION_, '1.7', 'lt')) {
      return true;
    }

    return $object->registerHook('displayReassurance');
}
