<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_2($object)
{
    foreach(array_keys($object->getTabOrderState()) as $state){
        $stateId = Configuration::get($state, 0);

        if($stateId){
            $sql = sprintf("
                SELECT
                    *
                FROM
                    `%sorder_state_lang`
                WHERE
                    id_order_state = %d
            ",
                _DB_PREFIX_,
                $stateId
            );

            $res = DB::getInstance()->executeS($sql);

            if( count($res)){
                foreach($res as $row){
                    $sql = sprintf("
                        UPDATE 
                            `%sorder_state_lang`
                        SET
                            `name` = '%s'
                        WHERE
                            id_order_state = %d AND
                            id_lang = %d                    
                    ",
                        _DB_PREFIX_,
                        str_replace('Faktoria', 'Spingo', $row['name']),
                        $row['id_order_state'],
                        $row['id_lang']
                    );
                    DB::getInstance()->execute($sql);

                    $destination = _PS_ROOT_DIR_ . sprintf('/img/tmp/order_state_mini_%d_%d.gif', $row['id_order_state'], $row['id_lang']);
                    @unlink($destination);
                }
            }

            $source = _PS_MODULE_DIR_ . $object->name . '/views/img/spingo.gif';
            $destination = _PS_ROOT_DIR_ . '/img/os/' . $stateId . '.gif';
            @unlink($destination);
            copy($source, $destination);
        }
    }
    return true;
}
