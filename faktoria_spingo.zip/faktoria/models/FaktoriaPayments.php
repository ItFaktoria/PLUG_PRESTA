<?php

class FaktoriaPayments extends ObjectModel
{
    public $id_faktoria_payment;
    public $id_order;
    public $id_faktoria;
    public $faktoria_key;
    public $status;
    public $date_add;

    public static $definition = [
        'table' => 'faktoria_payments',
        'primary' => 'id_faktoria_payment',
        'multilang' => false,
        'fields' => [
            'id_order' => ['type' => self::TYPE_INT, 'required' => true],
            'id_faktoria' => ['type' => self::TYPE_STRING, 'lang' => false],
            'faktoria_key' => ['type' => self::TYPE_STRING, 'lang' => false, 'required' => true],
            'status' => ['type' => self::TYPE_INT],
            'date_add' => ['type' => self::TYPE_DATE],
            'date_upd' => ['type' => self::TYPE_DATE],
        ],
    ];

    public function __construct($id = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id, $id_lang, $id_shop);
    }

    public static function findForOrder($idOrder){
        $sql = sprintf("
            SELECT
                id_faktoria_payment
            FROM
                `%sfaktoria_payments`
            WHERE
                `id_order` = %d
        ",
            _DB_PREFIX_,
            $idOrder);
        return Db::getInstance()->getRow($sql);
    }

    public static function checkIsSend($idOrder){
        $sql = sprintf("
            SELECT
                id_faktoria_payment
            FROM
                `%sfaktoria_payments`
            WHERE
                `id_order` = %d AND
                `id_faktoria` != ''
        ",
            _DB_PREFIX_,
            $idOrder);
        return Db::getInstance()->getRow($sql);
    }

    public static function checkByKey($key){
      $sql = sprintf("
          SELECT
              id_faktoria_payment
          FROM
              `%sfaktoria_payments`
          WHERE
              `faktoria_key` = '%s'
      ",
          _DB_PREFIX_,
          $key);
      return Db::getInstance()->getRow($sql);
    }

    public static function checkByFaktoriaId($key){
      $sql = sprintf("
          SELECT
              id_faktoria_payment
          FROM
              `%sfaktoria_payments`
          WHERE
              `id_faktoria` = '%s'
      ",
          _DB_PREFIX_,
          $key);
      return Db::getInstance()->getValue($sql);
    }

    public function delete()
    {
        if ((int) $this->id === 0) {
            return false;
        }

        return parent::delete();
    }
}
